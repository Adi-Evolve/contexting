// Simple test file
console.log('Test file loaded successfully');
const testVar = 'hello';
